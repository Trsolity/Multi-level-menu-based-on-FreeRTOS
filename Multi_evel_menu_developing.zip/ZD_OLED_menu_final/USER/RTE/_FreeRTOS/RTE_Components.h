
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'FreeRTOS' 
 * Target:  'FreeRTOS' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f10x.h"

/* Keil::Device:StdPeriph Drivers:BKP:3.5.0 */
#define RTE_DEVICE_STDPERIPH_BKP
/* Keil::Device:StdPeriph Drivers:PWR:3.5.0 */
#define RTE_DEVICE_STDPERIPH_PWR
/* Keil::Device:StdPeriph Drivers:RTC:3.5.0 */
#define RTE_DEVICE_STDPERIPH_RTC


#endif /* RTE_COMPONENTS_H */
